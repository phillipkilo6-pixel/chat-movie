# Chat Movie

A realtime messaging app that plays your conversation like a cartoon movie — live as you chat or later as a replay.

## Features
- Realtime chat powered by Socket.IO
- Per-room conversations (use the room ID box or URL hash)
- Movie Mode: auto-animated scenes for each message
- Optional voiceover using your browser's speech synthesis
- Lightweight Node.js server, zero database (JSON files per room for persistence)
- One-command run or Docker build
- Drop-in deploy to most Node-friendly hosts

## Quick Start (Local)
```bash
unzip chat-movie.zip
cd chat-movie
npm install
npm start
# open http://localhost:8080
```
Open the app in two different browsers or devices to chat with yourself.

## Rooms
- Set a Room ID in the header and click **Join**. Share that same ID with others.
- You can also use URL hashes: `http://localhost:8080/#my-room`

## Movie Mode
- Click **Watch Conversation**.
- Play/Pause/Restart, toggle **Voiceover**, adjust **Speed**, scrub the timeline.
- New incoming messages extend the movie automatically.

## Deploy (Drag & Drop Options)
- **Docker**: `docker build -t chat-movie . && docker run -p 8080:8080 chat-movie`
- **Any Node host** (Render, Railway, Fly, etc.): create a new app, upload the project, and set the start command to `npm start`. No environment variables required.
- **Static hosts** alone won't work, because realtime websockets require the Node server.

## Notes
- Persistence is JSON files written under `/data` per room. For fully stateless cloud deploys, you can remove writes or mount a volume.
- This is a self-contained baseline you can extend with auth, emoji reactions, file uploads, or exporting the movie to a video.
