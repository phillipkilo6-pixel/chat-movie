import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: "*"
  }
});

const PORT = process.env.PORT || 8080;
const DATA_DIR = path.join(__dirname, "data");
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);

// In-memory store: { [roomId]: Message[] }
const rooms = new Map();

function getRoomFile(roomId) {
  return path.join(DATA_DIR, `room-${roomId}.json`);
}

function loadRoom(roomId) {
  const file = getRoomFile(roomId);
  if (fs.existsSync(file)) {
    try {
      const data = JSON.parse(fs.readFileSync(file, "utf8"));
      rooms.set(roomId, data);
      return data;
    } catch (e) {
      console.error("Failed to parse room file", roomId, e);
      rooms.set(roomId, []);
      return [];
    }
  } else {
    rooms.set(roomId, []);
    return [];
  }
}

function saveRoom(roomId) {
  const file = getRoomFile(roomId);
  const data = rooms.get(roomId) || [];
  fs.writeFile(file, JSON.stringify(data, null, 2), () => {});
}

app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());

// Fetch messages for a room
app.get("/api/messages/:roomId", (req, res) => {
  const { roomId } = req.params;
  const msgs = rooms.get(roomId) || loadRoom(roomId);
  res.json({ messages: msgs });
});

// Health check
app.get("/health", (_req, res) => {
  res.json({ ok: true });
});

io.on("connection", (socket) => {
  let joinedRoomId = null;

  socket.on("join", ({ roomId, user }) => {
    if (!roomId) roomId = "default";
    joinedRoomId = roomId;
    socket.join(roomId);

    const msgs = rooms.get(roomId) || loadRoom(roomId);
    socket.emit("history", msgs);

    socket.to(roomId).emit("user-joined", { user, ts: Date.now() });
  });

  socket.on("send-message", (payload) => {
    const roomId = payload.roomId || joinedRoomId || "default";
    const msg = {
      id: payload.id || `${Date.now()}-${Math.random().toString(36).slice(2)}`,
      text: payload.text?.slice(0, 1000) || "",
      user: {
        name: payload.user?.name || "Anon",
        avatar: payload.user?.avatar || "koala",
        color: payload.user?.color || "#222"
      },
      ts: Date.now()
    };

    if (!rooms.has(roomId)) loadRoom(roomId);
    const arr = rooms.get(roomId);
    arr.push(msg);
    rooms.set(roomId, arr);
    saveRoom(roomId);

    io.to(roomId).emit("message", msg);
  });

  socket.on("disconnect", () => {
    if (joinedRoomId) {
      socket.to(joinedRoomId).emit("user-left", { ts: Date.now() });
    }
  });
});

httpServer.listen(PORT, () => {
  console.log(`Chat Movie server running on http://localhost:${PORT}`);
});
