/* global io */
// Basic state
const $ = (sel) => document.querySelector(sel);
const socket = io();

const nameInput = $("#name");
const colorInput = $("#color");
const roomInput = $("#roomId");
const messagesEl = $("#messages");
const inputEl = $("#input");
const formEl = $("#form");

const joinBtn = $("#joinBtn");
const saveIdentityBtn = $("#saveIdentity");
const openPlayerBtn = $("#openPlayer");

const playerOverlay = $("#playerOverlay");
const closePlayerBtn = $("#closePlayer");
const playBtn = $("#playBtn");
const pauseBtn = $("#pauseBtn");
const restartBtn = $("#restartBtn");
const ttsToggle = $("#ttsToggle");
const speedSelect = $("#speed");
const scrubInput = $("#scrub");
const timeLabel = $("#timeLabel");
const canvas = $("#movieCanvas");
const ctx = canvas.getContext("2d");

let user = {
  name: localStorage.getItem("cm_name") || `Guest-${Math.floor(Math.random()*999)}`,
  avatar: localStorage.getItem("cm_avatar") || "koala",
  color: localStorage.getItem("cm_color") || "#4f46e5"
};
let roomId = localStorage.getItem("cm_room") || "default";
let history = [];
let playing = false;
let playhead = 0; // milliseconds
let totalDuration = 0;
let queueIndex = 0;
let lastFrame = 0;

// Populate UI
nameInput.value = user.name;
colorInput.value = user.color;
roomInput.value = roomId;

// Avatar selection
document.querySelectorAll(".avatar").forEach(btn => {
  btn.addEventListener("click", () => {
    user.avatar = btn.dataset.av;
    localStorage.setItem("cm_avatar", user.avatar);
    btn.blur();
  });
});

saveIdentityBtn.addEventListener("click", () => {
  user.name = nameInput.value.trim() || user.name;
  user.color = colorInput.value;
  localStorage.setItem("cm_name", user.name);
  localStorage.setItem("cm_color", user.color);
  alert("Saved!");
});

joinBtn.addEventListener("click", () => {
  roomId = (roomInput.value || "default").trim();
  localStorage.setItem("cm_room", roomId);
  joinRoom();
});

function joinRoom() {
  messagesEl.innerHTML = "";
  history = [];
  queueIndex = 0;
  fetch(`/api/messages/${encodeURIComponent(roomId)}`)
    .then(r => r.json())
    .then(({messages}) => {
      history = messages;
      renderAll(history);
      socket.emit("join", { roomId, user });
      window.location.hash = `#${roomId}`;
      rebuildMovie();
    });
}

function renderAll(msgs) {
  for (const m of msgs) addMessage(m, false);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function addMessage(msg, scroll = true) {
  const li = document.createElement("li");
  li.className = "message " + (msg.user.name === user.name ? "me" : "them");

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.style.background = msg.user.name === user.name ? user.color : undefined;
  bubble.style.border = "1px solid rgba(255,255,255,.08)";
  bubble.style.boxShadow = "0 6px 18px rgba(0,0,0,.25)";

  bubble.textContent = msg.text;

  const meta = document.createElement("div");
  meta.className = "meta";
  const avatar = document.createElement("span");
  avatar.className = "avatar-emoji";
  avatar.textContent = avatarEmoji(msg.user.avatar) + " ";
  meta.appendChild(avatar);
  const who = document.createElement("span");
  who.textContent = msg.user.name + " • " + new Date(msg.ts).toLocaleTimeString();
  meta.appendChild(who);

  li.appendChild(bubble);
  li.appendChild(meta);
  messagesEl.appendChild(li);

  if (scroll) messagesEl.scrollTop = messagesEl.scrollHeight;
}

function avatarEmoji(av) {
  switch (av) {
    case "panda": return "🐼";
    case "tiger": return "🐯";
    case "cat": return "🐱";
    case "dog": return "🐶";
    case "alien": return "👽";
    default: return "🧸";
  }
}

// Send message
formEl.addEventListener("submit", (e) => {
  e.preventDefault();
  const text = inputEl.value.trim();
  if (!text) return;
  const payload = {
    roomId,
    text,
    user,
  };
  socket.emit("send-message", payload);
  inputEl.value = "";
});

socket.on("connect", () => {
  // Auto-join with saved room or URL hash
  roomId = window.location.hash?.slice(1) || roomId || "default";
  roomInput.value = roomId;
  joinRoom();
});

socket.on("history", (msgs) => {
  history = msgs;
  renderAll(history);
  rebuildMovie();
});

socket.on("message", (msg) => {
  history.push(msg);
  addMessage(msg, true);
  // If movie is open and playing live, extend duration
  rebuildMovie();
});

// ===== Movie Engine =====
/**
 * Convert each message into a "scene" with duration based on content.
 * We'll animate backgrounds, character bobbing, bubble pop-in, and optional TTS voiceover.
 */
let scenes = [];

function estimateDurationFor(text) {
  // ~12 chars per 250ms baseline (~48 chars/s) -> crude
  const base = Math.max(2200, text.length * 60);
  return Math.min(10000, base);
}

function rebuildMovie() {
  scenes = history.map((m, idx) => {
    const dur = estimateDurationFor(m.text);
    const bgHue = (idx * 37) % 360;
    return {
      id: m.id,
      text: m.text,
      who: m.user.name,
      avatar: m.user.avatar,
      color: m.user.color || "#4f46e5",
      ts: m.ts,
      bgHue,
      duration: dur
    };
  });
  totalDuration = scenes.reduce((a, s) => a + s.duration, 0);
  scrubInput.max = String(totalDuration);
  updateTimeLabel();
  queueIndex = 0;
}

function updateTimeLabel() {
  const fmt = (ms) => {
    const s = Math.floor(ms/1000);
    const m = Math.floor(s/60);
    const r = s % 60;
    return `${String(m).padStart(2,"0")}:${String(r).padStart(2,"0")}`;
  };
  timeLabel.textContent = `${fmt(playhead)} / ${fmt(totalDuration)}`;
}

function speak(text, voiceName) {
  if (!ttsToggle.checked) return;
  if (!("speechSynthesis" in window)) return;
  const utter = new SpeechSynthesisUtterance(text);
  utter.rate = parseFloat(speedSelect.value);
  // pick a friendly voice if available
  const voices = speechSynthesis.getVoices();
  const preferred = voices.find(v => v.name.toLowerCase().includes(voiceName?.toLowerCase())) || voices[0];
  if (preferred) utter.voice = preferred;
  speechSynthesis.speak(utter);
}

function stopSpeaking() {
  if ("speechSynthesis" in window) {
    speechSynthesis.cancel();
  }
}

function drawScene(scene, tNorm) {
  // tNorm 0..1 progress within the scene
  const W = canvas.width, H = canvas.height;

  // Background gradient that shifts hue per scene
  const hueA = scene.bgHue;
  const hueB = (scene.bgHue + 30) % 360;
  const g = ctx.createLinearGradient(0, 0, W, H);
  g.addColorStop(0, `hsl(${hueA} 70% 10%)`);
  g.addColorStop(1, `hsl(${hueB} 70% 20%)`);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);

  // Title-ish banner
  ctx.fillStyle = "rgba(255,255,255,.08)";
  ctx.fillRect(24, 24, W-48, 50);
  ctx.fillStyle = "rgba(255,255,255,.9)";
  ctx.font = "bold 22px Nunito, sans-serif";
  ctx.fillText(`${scene.who} says…`, 40, 58);

  // Character "bob"
  const bob = Math.sin(tNorm * Math.PI * 2) * 6;
  const leftSpeaker = (scene.who === user.name); // if it's me, place on right for variety
  const xChar = leftSpeaker ? W * 0.2 : W * 0.8;
  const yChar = H * 0.65 + bob;

  // Avatar as big emoji circle
  ctx.beginPath();
  ctx.arc(xChar, yChar, 60, 0, Math.PI*2);
  ctx.fillStyle = "rgba(0,0,0,.25)";
  ctx.fill();
  ctx.font = "64px serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(emojiFor(scene.avatar), xChar, yChar + 3);

  // Speech bubble pop-in
  const appear = easeOutBack(Math.min(tNorm*1.3, 1));
  const bubbleW = Math.min(W * 0.65, 40 + scene.text.length * 10);
  const bubbleH = 120 + Math.floor(scene.text.length / 40) * 20;
  const xBubble = leftSpeaker ? xChar + 80 : xChar - 80 - bubbleW;
  const yBubble = H * 0.3;

  ctx.save();
  ctx.translate(xBubble + bubbleW/2, yBubble + bubbleH/2);
  ctx.scale(appear, appear);
  ctx.translate(-bubbleW/2, -bubbleH/2);
  // bubble
  roundRect(0,0,bubbleW,bubbleH,20);
  ctx.fillStyle = hexToRgba(scene.color, 0.9);
  ctx.fill();
  // text
  ctx.fillStyle = "white";
  ctx.font = "bold 24px Nunito, sans-serif";
  ctx.textAlign = "left";
  ctx.textBaseline = "top";
  wrapText(ctx, scene.text, 16, 16, bubbleW - 32, 28);
  ctx.restore();

  // Progress bar
  ctx.fillStyle = "rgba(255,255,255,.2)";
  ctx.fillRect(24, H - 20, W - 48, 8);
  ctx.fillStyle = "rgba(255,255,255,.9)";
  ctx.fillRect(24, H - 20, (W - 48) * tNorm, 8);
}

function emojiFor(av) {
  switch (av) {
    case "panda": return "🐼";
    case "tiger": return "🐯";
    case "cat": return "🐱";
    case "dog": return "🐶";
    case "alien": return "👽";
    default: return "🧸";
  }
}

function easeOutBack(t) {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
}

function roundRect(x,y,w,h,r) {
  const rr = Math.min(r, w/2, h/2);
  ctx.beginPath();
  ctx.moveTo(x+rr,y);
  ctx.arcTo(x+w,y,x+w,y+h,rr);
  ctx.arcTo(x+w,y+h,x,y+h,rr);
  ctx.arcTo(x,y+h,x,y,rr);
  ctx.arcTo(x,y,x+w,y,rr);
  ctx.closePath();
}

function hexToRgba(hex, a=1) {
  const c = hex.replace("#","");
  const bigint = parseInt(c, 16);
  const r = (bigint >> 16) & 255;
  const g = (bigint >> 8) & 255;
  const b = bigint & 255;
  return `rgba(${r},${g},${b},${a})`;
}

function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
  const words = text.split(/\s+/);
  let line = "";
  for (let n = 0; n < words.length; n++) {
    const testLine = line + words[n] + " ";
    const metrics = ctx.measureText(testLine);
    if (metrics.width > maxWidth && n > 0) {
      ctx.fillText(line, x, y);
      line = words[n] + " ";
      y += lineHeight;
    } else {
      line = testLine;
    }
  }
  ctx.fillText(line, x, y);
}

// Playback loop
function loop(ts) {
  if (!playing) { requestAnimationFrame(loop); return; }
  if (!lastFrame) lastFrame = ts;
  const dt = (ts - lastFrame) * parseFloat(speedSelect.value);
  lastFrame = ts;
  playhead = Math.min(playhead + dt, totalDuration);
  scrubInput.value = String(Math.floor(playhead));
  updateTimeLabel();

  // find current scene & local time
  let t = playhead;
  let current = null;
  for (const sc of scenes) {
    if (t <= sc.duration) { current = [sc, t]; break; }
    t -= sc.duration;
  }
  if (!current && scenes.length) current = [scenes[scenes.length-1], scenes[scenes.length-1].duration];
  if (current) {
    const [scene, local] = current;
    const norm = scene.duration ? (local / scene.duration) : 1;
    drawScene(scene, norm);
  } else {
    // blank
    ctx.clearRect(0,0,canvas.width,canvas.height);
  }

  if (playhead >= totalDuration) {
    playing = false;
  }
  requestAnimationFrame(loop);
}

playBtn.addEventListener("click", () => {
  if (!scenes.length) rebuildMovie();
  playing = true;
  lastFrame = 0;
  // speak any scenes whose start passes now (quick heuristic)
  stopSpeaking();
  const [scene, _] = locateSceneAt(playhead);
  if (scene) speak(`${scene.who} says: ${scene.text}`, pickVoice(scene));
});

pauseBtn.addEventListener("click", () => {
  playing = false;
  stopSpeaking();
});

restartBtn.addEventListener("click", () => {
  playhead = 0;
  scrubInput.value = "0";
  updateTimeLabel();
  playing = true;
  lastFrame = 0;
  stopSpeaking();
  if (scenes[0]) speak(`${scenes[0].who} says: ${scenes[0].text}`, pickVoice(scenes[0]));
});

function pickVoice(scene) {
  // try to pick different voices based on avatar
  switch (scene.avatar) {
    case "tiger": return "Daniel";
    case "cat": return "Samantha";
    case "dog": return "Google UK English Male";
    case "alien": return "Fred";
    case "panda": return "Victoria";
    default: return "Google US English";
  }
}

function locateSceneAt(ms) {
  let t = ms;
  for (const sc of scenes) {
    if (t <= sc.duration) return [sc, t];
    t -= sc.duration;
  }
  return [null, 0];
}

scrubInput.addEventListener("input", (e) => {
  playhead = parseInt(e.target.value || "0", 10);
  updateTimeLabel();
  // Refresh immediately
  const [scene, local] = locateSceneAt(playhead);
  if (scene) drawScene(scene, scene.duration ? local/scene.duration : 1);
});

openPlayerBtn.addEventListener("click", () => {
  playerOverlay.classList.remove("hidden");
  rebuildMovie();
  playhead = 0;
  drawScene(scenes[0] || {bgHue:220, who:"", text:"", avatar:"koala", color:"#4f46e5"}, 0);
});

closePlayerBtn.addEventListener("click", () => {
  playerOverlay.classList.add("hidden");
  playing = false;
  stopSpeaking();
});

// Resize handling
function fitCanvas() {
  const rect = canvas.getBoundingClientRect();
  const ratio = 16/9;
  let w = rect.width;
  let h = w/ratio;
  if (h > window.innerHeight * 0.6) {
    h = window.innerHeight * 0.6;
    w = h * ratio;
  }
  canvas.width = Math.floor(w);
  canvas.height = Math.floor(h);
  const [scene, local] = locateSceneAt(playhead);
  if (scene) drawScene(scene, scene.duration ? local/scene.duration : 1);
}

window.addEventListener("resize", fitCanvas);
fitCanvas();
